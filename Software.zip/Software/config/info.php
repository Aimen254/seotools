<?php

return [

    'software' => [
        'name'      => 'phpRank',
        'author'    => 'Lunatio',
        'url'       => 'https://lunatio.com',
        'version'   => '13'
    ]

];
